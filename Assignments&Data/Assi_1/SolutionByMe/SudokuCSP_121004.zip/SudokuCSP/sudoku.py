"""
This program is to solve a Sudoku puzzle using backtracking search with
combination of forward checking and heuristics.

Three heuristics are used:
1. Most constrained variable
   This heuristic is first applied to choose the variable has the fewest
   "legal" moves. 
2. Most constraining variable
   If there is a tie when applying the first heuristic, this heuristic is used
   to choose the variable with the most constraints on remaining variables. 
3. Least constraining value
   This heuristic is applied to sort domain values of the selected variable
   so that the value which leaves the fewest values in the remaining variables
   is searched first.

Usage:
    python sudoku.py [-f|-h] <puzzle_file>

Where:
    <puzzle_file>    the file containing the sudoku puzzle to solve
    -f    solve the puzzle using backtracking search with forward checking
    -h    solve the puzzle using backtracking search with forward checking 
          and the 3 heuristics
          
Examples:
    To find solution for the puzzle stored in easy.txt file with only 
    backtracking search, use the following command:
    
        python sudoku.py easy.txt
    
    To find the solution using backtracking with forward checking, use the
    following command:
    
        python sudoku.py -f easy.txt
    
    And to apply both forward checking and the three heuristics, use the 
    following command:
    
        python sudoku.py -h easy.txt
    
Format of input file:
    Each line of the input file represents a row in the puzzle which is a 
    9-character string containing digits (1..9) or dash (-) character 
    indicating blank cells.
    Line starting with # is considered as comments and not a part of the 
    puzzle.
"""
import sys
from os import times

class Sudoku:
    """Represent a Sudoku puzzle as a 2-dimension array where each element is
    an int value from 0 to 9. Zero indicates blank cells.
    """
    
    def __init__(self, filename):
        """Create a new Sudoku puzzle by loading its initial state from the
        given file."""
        self.sudoku = []

        # open the puzzle file
        sudoku_file = open(filename, "U")
        # Read each line
        for line in sudoku_file:
            line = line.strip()
            if line.startswith('#'):
                continue    # ignore comments
            
            # Each line is a 9-character string containing digits (1..9) or 
            # dash (-) character which indicates blank cells.
            row = [int(c) if c.isdigit() else 0 
                   for c in line.strip()]
            self.sudoku.append(row)
            
        sudoku_file.close()
        
    def get(self, row, col):
        """Return the value at the given location (row, col)"""
        return self.sudoku[row][col]
    
    def set(self, row, col, value):
        """Set the value at the given location (row, col)"""
        self.sudoku[row][col] = value
        
    def get_row(self, row):
        """Return values in of the row at the given index (0..8)"""
        return self.sudoku[row]
        
    def get_col(self, col):
        """Return values in of the column at the given index (0..8)"""
        return [self.sudoku[row][col] for row in range(9)]
    
    def get_block(self, block_row, block_col):
        """Return values in of the block at the given index (0..2, 0..2)."""
        
        # The location of the starting cell of the block
        start_row = block_row * 3
        start_col = block_col * 3
        
        # Return values of 9 cells in the given block
        return [self.sudoku[start_row + row][start_col + col]
                for row in range(3) 
                for col in range(3)]
        
    def print_state(self):
        """Print the current state of the puzzle"""
        for row in self.sudoku:
            for cell in row:
                if cell > 0:
                    print cell, 
                else:
                    print '-',
            print
        print
    
class SudokuCSP:
    """
    Represents Sudoku puzzle as a Constraint satisfaction problem (CSP) with 
    the following characteristics:
    Variables:    {X(0,0), .., X(8,8)}
    Domains:      {1, .., 9}
    Constraints:
        Row Constraint: for each row i, i = 0..8: 
                        every cell in the row has different value
        Col Constraint: for each column i, i = 0..8:
                        every cell in the column has different value
        Block Constraint: for each block (i,j) i,j = 0..2:
                        every cell in the block has different value
    Goals: Every variable is assigned a value such that all constraints are
    satisfied.
    """
    
    DOMAIN_VALUES = [1,2,3,4,5,6,7,8,9]
    
    def __init__(self, assignment, forwardchecking, heuristics):
        self.do_forwardchecking = forwardchecking
        self.use_heuristics = heuristics
    
    def is_complete(self, assignment):
        """Test whether the given assignment is a complete sudoku state."""

        # Test row constraints
        for i in range(9):
            values = assignment.get_row(i)
            if 0 in values:
                return False
            if sorted(values) != SudokuCSP.DOMAIN_VALUES:
                return False

        # Test col constraints
        for i in range(9):
            values = assignment.get_col(i)
            if 0 in values:
                return False
            if sorted(values) != SudokuCSP.DOMAIN_VALUES:
                return False

        # Test block constraints
        for i in range(3):
            for j in range(3):
                values = assignment.get_block(i, j)
                if 0 in values:
                    return False
                if sorted(values) != SudokuCSP.DOMAIN_VALUES:
                    return False
                        
        return True

    def select_unassigned_var(self, assignment):
        """
        Select unassigned variables in the given sudoku assignment.
        Return the location of the first cell having value of zero if no
        heuristic is used. Otherwise, 3 heuristics are applied to choose
        among unassigned variables.
        """
        unassignments = []
        
        for row in range(9):
            for col in range(9):
                if assignment.get(row, col) == 0:
                    if not self.use_heuristics:
                        # return the first unassigned variable found
                        return (row, col)
                    else:
                        unassignments.append((row, col))
        
        if self.use_heuristics:
            # use heuristics to choose one of unassigned variables
            return self.apply_heuristics(assignment, unassignments)
                
        return None # all variables have been assigned
    
    def apply_heuristics(self, assignment, var_list):
        """
        Apply most constrained variable and most constraining variable
        heuristics to choose one of unassigned variables. 
        """
        
        # For choosing the variable which has the fewest "legal" moves
        min_choices = 10    # we will have maximum o 9 values
        min_var = None
        
        for var in var_list:
            # Get number of values of the domain of the variable
            choices = len(self.get_domain_values(assignment, var))
            
            if choices < min_choices:
                # Save the most constrained variable
                min_var = var
                min_choices = choices
            
            elif choices == min_choices:
                # There is a tie.
                # Apply the most constraining variable heuristic
                min_var = self.most_constraining_variable(assignment, 
                                                          min_var, var)
                
        return min_var
    
    def most_constraining_variable(self, assignment, var1, var2):
        """Choose between two variables that has the most constraints on
        remaining variables."""
        count1 = self.count_constraints(assignment, var1)
        count2 = self.count_constraints(assignment, var2)
        return var1 if count1 < count2 else var2
        
    def count_constraints(self, assignment, var):
        """Count number of constraints between the given variable and other
        unassigned variables."""
        row, col = var
        
        count = 0
        
        # Count variables which is row-constraint with the given variable 
        for i in range(9):
            if i != col and assignment.get(row, i) == 0:
                count += 1
        # Count variables which is col-constraint with the given variable 
        for i in range(9):
            if i != row and assignment.get(i, col) == 0:
                count += 1
        # Count variables which is block-constraint with the given variable
        start_i = row // 3 * 3
        start_j = col // 3 * 3
        for i in range(start_i, start_i + 3):
            for j in range(start_j, start_j + 3):
                if i != row and j != col and assignment.get(i, j) == 0:
                    count += 1
        
        return count
    
    def get_domain_values(self, assignment, var):
        """Return domain values (sorted) of the given variable."""

        if self.do_forwardchecking:
            row, col = var
            
            # get values which are used by the cells on the same row, column,
            # or block
            row_values = assignment.get_row(row)
            col_values = assignment.get_col(col)
            block_values = assignment.get_block(row // 3, col // 3)
            
            values = [val for val in SudokuCSP.DOMAIN_VALUES
                      # exclude values which is inconsistent with the constraints
                      if val not in row_values and val not in col_values
                      and val not in block_values]
            
            if self.use_heuristics:
                # Apply least-constraining value heuristic
                values.sort(lambda x, y:
                            cmp(self.least_constraining_value_count(assignment, var, x),
                                self.least_constraining_value_count(assignment, var, y)))
                
            return values

        else:
            # Without forward checking, all variables have the same domain
            return SudokuCSP.DOMAIN_VALUES
    
    def least_constraining_value_count(self, assignment, var, value):
        """Count number of values for the remaining variables to choose if
        the given variable is set with the given value"""
        row, col = var

        row_values = assignment.get_row(row)
        col_values = assignment.get_col(col)
        block_values = assignment.get_block(row // 3, col // 3)
        
        count = 0
        for val in SudokuCSP.DOMAIN_VALUES:
            if val != value and val not in row_values and \
                val not in col_values and val not in block_values:
                count +=1
        
        return count

    def test_constraints(self, assignment, var, value):
        """Test if the given value of the given variable is consistent with
        all constraints."""
        row, col = var # Get row, column index of the variable

        # Test row constraint     
        if value in assignment.get_row(row):
            return False
        # Test col constraint
        if value in assignment.get_col(col):
            return False
        # Test block constraint
        if value in assignment.get_block(row // 3, col // 3):
            return False
        
        return True

    def add_var(self, assignment, var, value):
        """Add the value to the specified variable of the assignment"""
        row, col = var
        assignment.set(row, col, value)

    def remove_var(self, assignment, var, value):
        """Remove the value from the specified variable of the assignment"""
        row, col = var
        assignment.set(row, col, 0)

nodes_count = 0 # For counting number of nodes

def recursive_backtrack(assignment, csp):
    """
    Do a recursive backtracking search on the given assignment using the given
    CSP specification. The csp is an object which the following methods:
    
        is_complete(assignment):
            Test whether the assignment is complete
        
        select_unassigned_var(assignment):
            Select an unassigned variables of the assignment
            Return an object to identify the variable
            
        get_domain_values(assignment, var):
            Return domain values for the given variable of the assignment.
        
        test_constraints(assignment, var, value):
            Test if the given value of the variable is consistent with the 
            assignment according to the constraints.
        
        add_var(assignment, var, value):
            Add the given value to the variable of the assignment
        
        remove_var(assignment, var, value)
            Remove the value of the variable from the assignment
        
    Return a solution, or False indicating failure
    """
    global nodes_count
    
    if csp.is_complete(assignment):
        # The goal is reached, return the solution
        return assignment
    
    # Select an unassigned variables from the assignment
    var = csp.select_unassigned_var(assignment)
    
    # Try all values in the domain of the selected variable
    for value in csp.get_domain_values(assignment, var):
        nodes_count += 1
        
        # Test if value is consistent wit assignment according to 
        # Constraints(csp)
        if csp.test_constraints(assignment, var, value):
            csp.add_var(assignment, var, value)

            # Recursive search for solution
            result = recursive_backtrack(assignment, csp)
            if result != False:
                # Solution found
                return result

            # Remove the tested value of the variable
            csp.remove_var(assignment, var, value)
    
    # Reached here, all possible values tested with no solution found 
    return False
    

def main():
    """
    Main function to read command line parameter for the puzzle, solve and 
    print out the solution (if any) including performance data (time, nodes). 
    """
    
    # input file containing the initial puzzle state
    sudoku_file = None
    # do backtracking with forward checking
    do_forwardchecking = False
    # backtracking search with forward checking and the 3 heuristics
    use_heuristics = False

    # get command line parameters
    for arg in sys.argv[1:]:
        if arg == "-f":
            do_forwardchecking = True
        elif arg == "-h":
            use_heuristics = True
            do_forwardchecking = True
        else:
            sudoku_file = arg
            
    if not sudoku_file:
        print "Usage: python sudoku.py [-f|-h] <puzzle_file>"
        return
    
    # read the puzzle file for the initial state
    sudoku = Sudoku(sudoku_file)
    
    print "Initial State:"
    sudoku.print_state()
    
    print "Backtracking search",
    if do_forwardchecking:
        print "with forward checking",
        if use_heuristics:
            print "and 3 heuristics",
    print
    
    # Create the CSP from the given puzzle with optional forward checking and
    # heuristics.
    csp = SudokuCSP(sudoku, do_forwardchecking, use_heuristics)
    
    # Find the solution using backtracking search    
    start = times() # Record the start time
    solution = recursive_backtrack(sudoku, csp)
    end = times() # Record the end time
    
    # Print the solution if any
    if solution:
        print "Solution Found:"
        solution.print_state()
    else:
        print "Solution not found"
    
    # compute the time to complete the puzzle
    time = end[0] - start[0]
    print "Puzzle is solved in", time, "seconds with", 
    print nodes_count, "nodes searched."

    
if __name__ == '__main__':
    main()
