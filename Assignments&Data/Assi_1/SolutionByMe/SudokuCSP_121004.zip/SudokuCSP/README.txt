Sudoku Solver using CSP formulation
-----------------------------------


This program is to solve a Sudoku puzzle using backtracking search with
combination of forward checking and heuristics.

Three heuristics are used:
1. Most constrained variable
   This heuristic is first applied to choose the variable has the fewest
   "legal" moves. 
2. Most constraining variable
   If there is a tie when applying the first heuristic, this heuristic is used
   to choose the variable with the most constraints on remaining variables. 
3. Least constraining value
   This heuristic is applied to sort domain values of the selected variable
   so that the value which leaves the fewest values in the remaining variables
   is searched first.

Source Code
-----------

sudoku.py  The sudoku solver program implemented in Python (version 2.7)


Test Case Files
---------------
easy.txt        The easy puzzle
medium.txt      The medium puzzle
difficult.txt   The difficult puzzle
evil.txt        The evil puzzle


Running Instruction
-------------------

Usage:
    python sudoku.py [-f|-h] <puzzle_file>

Where:
    <puzzle_file>    the file containing the sudoku puzzle to solve
    -f    solve the puzzle using backtracking search with forward checking
    -h    solve the puzzle using backtracking search with forward checking 
          and the 3 heuristics
          
Examples:
    To find solution for the puzzle stored in easy.txt file with only 
    backtracking search, use the following command:
    
        python sudoku.py easy.txt
    
    To find the solution using backtracking with forward checking, use the
    following command:
    
        python sudoku.py -f easy.txt
    
    And to apply both forward checking and the three heuristics, use the 
    following command:
    
        python sudoku.py -h easy.txt

Format of input file:
    Each line of the input file represents a row in the puzzle which is a 
    9-character string containing digits (1..9) or dash (-) character 
    indicating blank cells.
    Line starting with # is considered as comments and not a part of the 
    puzzle.
